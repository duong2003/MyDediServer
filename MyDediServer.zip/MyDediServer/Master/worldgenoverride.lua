return {
    override_enabled = true,
    preset = "SURVIVAL_TOGETHER",
    overrides = {},
}
